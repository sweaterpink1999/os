from cybervpn import *
import subprocess
import datetime as DT
import sys
import asyncio
import aiohttp
from telethon.sync import TelegramClient
import sqlite3
import random

@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    async def trial_ssh_(event):
        user = "Trial-" + str(random.randint(100, 1000))
        pw = "free"
        Quota = "1"
        ip = "1"
        exp = "1"       

        await event.edit("**Please Wait...**")
        cmd = f'printf "%s\n" "{user}" "{pw}" "{Quota}" "{ip}" "{exp}" | addssh-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            print(f'Subprocess output: {a}')
            await event.respond(f"Terjadi kesalahan: {e}\nSubproses output: {a}")
            return  # Stop execution if there's an error
        
        try:
            with open('/etc/xray/dns', 'r') as file:
              NS = file.read().strip()
        except FileNotFoundError:
              NS = "Not found"

        try:
            with open('/etc/slowdns/server.pub', 'r') as file:
              PUB = file.read().strip()
        except FileNotFoundError:
              PUB = "Not found"

            

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
◇━━━━━━━━━━━━━━━━━◇
      **◇⟨SSH Account ⟩◇**
◇━━━━━━━━━━━━━━━━━◇
**» ISP:** `{z["isp"]}`
**» Location:** `{z["country"]}`
**» Host:** `{DOMAIN}`
**» Host SlowDNS:** `{NS}`
**» Username:** `{user}`
**» Password:** `{pw}`
**» Limit Quota :** `{Quota} GB`
**» Limit Login :** `{ip} HP`
◇━━━━━━━━━━━━━━━━━◇
**» Pub Key:** `{PUB}`
**» Port OpenSsh :** 22
**» Port Dropbear :** 143,109
**» Port Ssh Ws :** 80,8080,2086,8880
**» Port Ssh Ws/Tls :**443,8443
**» Port Ssh Ssl/Tls :**443
**» Port Ssh UDP :** 1-65535 
**» BadVPN UDP :** 7100,7300,7300
◇━━━━━━━━━━━━━━━━━◇
**⟨FORMAT HTTP CUSTOM⟩**
`{DOMAIN}:1-65535@{user}:{pw}`
◇━━━━━━━━━━━━━━━━━◇
**⟨Save Account⟩**
https://{DOMAIN}:81/ssh-{user}.txt
◇━━━━━━━━━━━━━━━━━◇
**⟨Payload Websocket⟩**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
◇━━━━━━━━━━━━━━━━━◇
**» Expired Until:** {today}
◇━━━━━━━━━━━━━━━━━◇
"""
        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(sender.id)  # Pastikan gunakan sender.id, bukan user_id
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await trial_ssh_(event)
        else:
            await event.answer(f'Akses Ditolak...!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')
